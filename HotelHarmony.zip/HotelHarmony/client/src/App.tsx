import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import AdminPage from "@/pages/admin-page";
import BookingPage from "@/pages/booking-page";
import MyBookingsPage from "@/pages/my-bookings";
import GalleryPage from "@/pages/gallery-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "@/hooks/use-auth";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

function Navigation() {
  const { user, logoutMutation } = useAuth();

  return (
    <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-sm border-b z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <Button variant="link" className="text-2xl font-bold p-0">
            Luxury Hotel
          </Button>
        </Link>
        <div className="space-x-6">
          <Link href="/#rooms">
            <Button variant="link">Rooms</Button>
          </Link>
          <Link href="/gallery">
            <Button variant="link">Gallery</Button>
          </Link>
          {user ? (
            <>
              <Link href="/bookings">
                <Button variant="link">My Bookings</Button>
              </Link>
              {user.isAdmin && (
                <Link href="/admin">
                  <Button variant="link">Admin</Button>
                </Link>
              )}
              <Button 
                variant="link"
                onClick={() => logoutMutation.mutate()} 
                disabled={logoutMutation.isPending}
              >
                Logout
              </Button>
            </>
          ) : (
            <Link href="/auth">
              <Button variant="link">Login / Register</Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}

function Router() {
  return (
    <>
      <Navigation />
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/gallery" component={GalleryPage} />
        <ProtectedRoute path="/admin" component={AdminPage} />
        <ProtectedRoute path="/booking/:id" component={BookingPage} />
        <ProtectedRoute path="/bookings" component={MyBookingsPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;