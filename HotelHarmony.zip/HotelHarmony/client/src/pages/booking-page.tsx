import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema, type InsertBooking, type Room } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, Redirect } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

export default function BookingPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();

  // Validate room ID is a valid number
  const roomId = id ? parseInt(id) : NaN;
  if (isNaN(roomId)) {
    return <Redirect to="/" />;
  }

  const { data: room, isLoading: roomLoading } = useQuery<Room>({
    queryKey: [`/api/rooms/${roomId}`],
    enabled: !isNaN(roomId)
  });

  const form = useForm<InsertBooking>({
    resolver: zodResolver(insertBookingSchema.extend({
      checkIn: insertBookingSchema.shape.checkIn,
      checkOut: insertBookingSchema.shape.checkOut,
    })),
    defaultValues: {
      roomId,
      guests: 1,
    }
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: InsertBooking) => {
      const res = await apiRequest("POST", "/api/bookings", data);
      const booking = await res.json();

      // Send booking to webhook
      await fetch("https://hook.eu2.make.com/jen7ayi16byho4snlmuu6sraxdu9ddra", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(booking)
      });

      return booking;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      toast({
        title: "Booking Confirmed!",
        description: "Your room has been successfully booked."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  if (!user) {
    return <Redirect to="/auth" />;
  }

  if (roomLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!room) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto"
      >
        <h1 className="text-3xl font-bold mb-8">Book {room.name}</h1>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(data => bookingMutation.mutate(data))} className="space-y-6">
            <FormField
              control={form.control}
              name="checkIn"
              render={({ field: { value, onChange, ...field } }) => (
                <FormItem>
                  <FormLabel>Check-in Date</FormLabel>
                  <FormControl>
                    <Input 
                      type="date" 
                      value={value instanceof Date ? value.toISOString().split('T')[0] : value}
                      onChange={e => onChange(new Date(e.target.value))}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="checkOut"
              render={({ field: { value, onChange, ...field } }) => (
                <FormItem>
                  <FormLabel>Check-out Date</FormLabel>
                  <FormControl>
                    <Input 
                      type="date" 
                      value={value instanceof Date ? value.toISOString().split('T')[0] : value}
                      onChange={e => onChange(new Date(e.target.value))}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="guests"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Number of Guests</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="1" 
                      max={room.capacity}
                      {...field}
                      onChange={e => field.onChange(parseInt(e.target.value))}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="specialRequests"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Requests</FormLabel>
                  <FormControl>
                    <Textarea {...field} value={field.value || ''} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full" 
              disabled={bookingMutation.isPending}
            >
              {bookingMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Processing...
                </>
              ) : (
                'Confirm Booking'
              )}
            </Button>
          </form>
        </Form>
      </motion.div>
    </div>
  );
}