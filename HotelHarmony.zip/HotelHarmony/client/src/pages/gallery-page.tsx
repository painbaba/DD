import { useQuery } from "@tanstack/react-query";
import { Room } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function GalleryPage() {
  const { data: rooms, isLoading } = useQuery<Room[]>({
    queryKey: ["/api/rooms"]
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const allImages = rooms?.flatMap(room => room.images) || [];

  return (
    <div className="min-h-screen p-8">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Our Gallery
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {allImages.map((image, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.05 }}
            className="aspect-square overflow-hidden rounded-lg shadow-lg"
          >
            <img
              src={image}
              alt={`Gallery image ${index + 1}`}
              className="w-full h-full object-cover"
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
}
