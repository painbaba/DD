import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Room } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Loader2, MapPin, Wifi, Coffee, Car, Phone, Mail } from "lucide-react";

export default function HomePage() {
  const { user } = useAuth();
  const { data: rooms, isLoading } = useQuery<Room[]>({ 
    queryKey: ["/api/rooms"]
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="pt-24 pb-16 text-center bg-gradient-to-b from-primary/10 to-background min-h-[80vh] flex flex-col items-center justify-center"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          Experience Luxury & Comfort
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto px-4 mb-8">
          Discover our exquisite rooms and world-class amenities in the heart of the city
        </p>
        <Button size="lg" asChild>
          <Link href="#rooms">View Our Rooms</Link>
        </Button>
      </motion.div>

      {/* Amenities Section */}
      <section id="amenities" className="py-16 bg-primary/5">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12 text-center"
          >
            Our Amenities
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex flex-col items-center text-center"
            >
              <Wifi className="h-8 w-8 mb-4" />
              <h3 className="font-semibold mb-2">Free Wi-Fi</h3>
              <p className="text-muted-foreground">High-speed internet throughout the hotel</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="flex flex-col items-center text-center"
            >
              <Coffee className="h-8 w-8 mb-4" />
              <h3 className="font-semibold mb-2">Restaurant</h3>
              <p className="text-muted-foreground">24/7 dining with room service</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="flex flex-col items-center text-center"
            >
              <Car className="h-8 w-8 mb-4" />
              <h3 className="font-semibold mb-2">Free Parking</h3>
              <p className="text-muted-foreground">Secure parking for all guests</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="flex flex-col items-center text-center"
            >
              <MapPin className="h-8 w-8 mb-4" />
              <h3 className="font-semibold mb-2">Prime Location</h3>
              <p className="text-muted-foreground">Located in the heart of the city</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Rooms Section */}
      <section id="rooms" className="container mx-auto px-4 py-16">
        <motion.h2 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-3xl font-bold mb-8"
        >
          Our Rooms
        </motion.h2>

        {isLoading ? (
          <div className="flex justify-center">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {rooms?.map((room, index) => (
              <motion.div
                key={room.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>{room.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <img 
                      src={room.images[0]} 
                      alt={room.name}
                      className="w-full h-48 object-cover rounded-md mb-4"
                    />
                    <p className="text-sm text-muted-foreground mb-4">
                      {room.description}
                    </p>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Capacity</span>
                        <span className="font-medium">{room.capacity} Guests</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-lg font-bold">
                          ${room.price} / night
                        </span>
                        {user ? (
                          <Button asChild>
                            <Link href={`/booking/${room.id}`}>Book Now</Link>
                          </Button>
                        ) : (
                          <Button asChild>
                            <Link href="/auth">Login to Book</Link>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-primary/5 py-16">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-12 text-center"
          >
            Contact Us
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-4"
            >
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5" />
                <span>+1 234 567 890</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5" />
                <span>info@luxuryhotel.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5" />
                <span>123 Luxury Street, City Center</span>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="aspect-w-16 aspect-h-9"
            >
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434509374!2d144.95373631531973!3d-37.817327679751854!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d4c2b349649%3A0xb6899234e561db11!2sHotel!5e0!3m2!1sen!2sus!4v1644933137527!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0, borderRadius: '0.5rem' }}
                allowFullScreen
                loading="lazy"
              />
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}