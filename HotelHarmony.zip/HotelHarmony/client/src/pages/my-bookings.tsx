import { useQuery } from "@tanstack/react-query";
import { Booking, Room } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Calendar, Users, CheckCircle, XCircle } from "lucide-react";
import { motion } from "framer-motion";
import { Redirect } from "wouter";

export default function MyBookingsPage() {
  const { user } = useAuth();
  
  const { data: bookings, isLoading } = useQuery<(Booking & { room?: Room })[]>({
    queryKey: ["/api/bookings"],
    enabled: !!user
  });

  if (!user) {
    return <Redirect to="/auth" />;
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <h1 className="text-3xl font-bold mb-8">My Bookings</h1>

        <div className="space-y-6">
          {bookings?.map((booking) => (
            <motion.div
              key={booking.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Booking #{booking.id}</span>
                    <span className="flex items-center text-sm font-normal">
                      {booking.status === 'confirmed' ? (
                        <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 mr-1" />
                      )}
                      {booking.status}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        Check-in: {new Date(booking.checkIn).toLocaleDateString()}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        Check-out: {new Date(booking.checkOut).toLocaleDateString()}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Users className="h-4 w-4 mr-2" />
                        {booking.guests} Guests
                      </div>
                    </div>
                    {booking.specialRequests && (
                      <div>
                        <h4 className="font-medium mb-1">Special Requests</h4>
                        <p className="text-sm text-muted-foreground">
                          {booking.specialRequests}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {bookings?.length === 0 && (
            <Card>
              <CardContent className="text-center py-6">
                <p className="text-muted-foreground">
                  You don't have any bookings yet.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </motion.div>
    </div>
  );
}
