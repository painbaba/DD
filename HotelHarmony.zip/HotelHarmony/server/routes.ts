import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertRoomSchema, insertBookingSchema, insertContentSchema } from "@shared/schema";
import { z } from "zod";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Room routes
  app.get("/api/rooms", async (req, res) => {
    const rooms = await storage.getAllRooms();
    res.json(rooms);
  });

  app.post("/api/rooms", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);
    const room = await storage.createRoom(insertRoomSchema.parse(req.body));
    res.status(201).json(room);
  });

  app.patch("/api/rooms/:id", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);
    const room = await storage.updateRoom(parseInt(req.params.id), req.body);
    res.json(room);
  });

  app.get("/api/rooms/:id", async (req, res) => {
    const roomId = parseInt(req.params.id);
    if (isNaN(roomId)) {
      return res.status(400).json({ message: "Invalid room ID" });
    }

    try {
      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      res.json(room);
    } catch (error) {
      console.error("Error fetching room:", error);
      res.status(500).json({ message: "Failed to fetch room" });
    }
  });

  // Booking routes
  app.post("/api/bookings", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const booking = await storage.createBooking({
        ...insertBookingSchema.parse(req.body),
        userId: req.user.id
      });

      // Send booking details to webhook
      try {
        await fetch("https://hook.eu2.make.com/jen7ayi16byho4snlmuu6sraxdu9ddra", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(booking)
        });
      } catch (error) {
        console.error("Failed to send booking to webhook:", error);
      }

      res.status(201).json(booking);
    } catch (error) {
      console.error("Error creating booking:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to create booking" });
    }
  });

  app.get("/api/bookings", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const bookings = req.user.isAdmin
      ? await storage.getAllBookings()
      : await storage.getUserBookings(req.user.id);
    res.json(bookings);
  });

  // Content routes
  app.get("/api/content", async (req, res) => {
    const content = await storage.getAllContent();
    res.json(content);
  });

  app.post("/api/content", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);
    const content = await storage.createContent(insertContentSchema.parse(req.body));
    res.status(201).json(content);
  });

  app.patch("/api/content/:id", async (req, res) => {
    if (!req.user?.isAdmin) return res.sendStatus(403);
    const content = await storage.updateContent(parseInt(req.params.id), req.body);
    res.json(content);
  });

  const httpServer = createServer(app);
  return httpServer;
}